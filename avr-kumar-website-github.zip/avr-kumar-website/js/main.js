const menu=document.querySelector('.menu-button'),links=document.querySelector('.links');
menu.addEventListener('click',()=>{const open=links.classList.toggle('open');menu.setAttribute('aria-expanded',String(open))});
links.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{links.classList.remove('open');menu.setAttribute('aria-expanded','false')}));
document.querySelectorAll('[data-story]').forEach(button=>button.addEventListener('click',()=>{const dialog=document.getElementById('dialog-'+button.dataset.story);dialog.showModal();dialog.scrollTop=0;document.body.style.overflow='hidden'}));
document.querySelectorAll('dialog').forEach(dialog=>{dialog.querySelector('[data-close]').addEventListener('click',()=>dialog.close());dialog.addEventListener('close',()=>{document.body.style.overflow=''});dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close()}})});
document.querySelector('#year').textContent=new Date().getFullYear();
const collections=[...document.querySelectorAll('.story-collection')];
const collectionToggle=document.getElementById('collection-toggle');
function updateCollectionToggle(){const allOpen=collections.every(group=>group.open);collectionToggle.textContent=allOpen?'Collapse all collections':'Expand all collections';collectionToggle.setAttribute('aria-expanded',String(allOpen));}
collectionToggle.addEventListener('click',()=>{const shouldOpen=!collections.every(group=>group.open);collections.forEach(group=>{group.open=shouldOpen});updateCollectionToggle()});
collections.forEach(group=>group.addEventListener('toggle',updateCollectionToggle));
function revealLinkedStory(){if(!location.hash)return;const target=document.getElementById(decodeURIComponent(location.hash.slice(1)));const group=target?.closest('.story-collection');if(group){group.open=true;updateCollectionToggle();requestAnimationFrame(()=>target.scrollIntoView({block:'start'}));}}
window.addEventListener('hashchange',revealLinkedStory);updateCollectionToggle();
// Always open at the top of the page, except for direct links to a story.
if('scrollRestoration' in history)history.scrollRestoration='manual';
function isStoryLink(){if(!location.hash)return false;const t=document.getElementById(decodeURIComponent(location.hash.slice(1)));return !!t?.closest('.story-collection');}
function openAtTop(){if(isStoryLink()){revealLinkedStory();return;}if(location.hash)history.replaceState(null,'',location.pathname+location.search);window.scrollTo({top:0,left:0,behavior:'instant'});}
openAtTop();window.addEventListener('load',openAtTop);window.addEventListener('pageshow',e=>{if(e.persisted)openAtTop()});


// ---- Optional visit statistics (GoatCounter) ----
// Switched on by putting your GoatCounter code in js/config.js. Nothing is loaded while it is empty.
(function(){
  const code=((window.SITE_CONFIG||{}).goatcounterCode||'').trim().toLowerCase();
  if(!/^[a-z0-9-]+$/.test(code))return;
  const note=document.querySelector('.analytics-note'); if(note)note.hidden=false;
  const gc=document.createElement('script');
  gc.async=true; gc.src='https://gc.zgo.at/count.js';
  gc.dataset.goatcounter='https://'+code+'.goatcounter.com/count';
  document.head.appendChild(gc);
  // Also record which stories are opened, as "story/<name>" events.
  document.querySelectorAll('[data-story]').forEach(btn=>btn.addEventListener('click',()=>{
    const title=(document.getElementById('title-'+btn.dataset.story)||{}).textContent||btn.dataset.story;
    if(window.goatcounter&&window.goatcounter.count)window.goatcounter.count({path:'story/'+btn.dataset.story,title:title,event:true});
  }));
})();
