// Site settings: the only file you need to edit to switch on visit statistics.
//
// To count visits: create a free account at https://www.goatcounter.com,
// then put the code you chose between the quotes below. Example: "avrkumar"
// (from https://avrkumar.goatcounter.com). Leave it empty to count nothing.

window.SITE_CONFIG = {
  goatcounterCode: ""
};
